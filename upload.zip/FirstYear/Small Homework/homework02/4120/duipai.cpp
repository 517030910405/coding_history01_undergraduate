#include<cmath>
#include<cstdio>
using namespace std;
int main(){
	
	
	
}