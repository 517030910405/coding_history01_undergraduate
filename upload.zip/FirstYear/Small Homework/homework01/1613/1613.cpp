#include<cmath>
#include<cstdio>
using namespace std;
const int N=1000+3;
const int W=1000+3;
int fa[N];
int son[N],bro[N];
int ans[N][W];
int szans[N];
int main(){
	
	
	
}
