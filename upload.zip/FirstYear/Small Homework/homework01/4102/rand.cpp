#include<cstdio>
#include<cstdlib>
using namespace std;
int a;
int main(){
	rand();
	rand();
	rand();
	printf("10000 3000000 \n");
	for (int f1=1;f1<=3000000;f1++){
		printf(" %d",rand());
	}
	
	
}