/*
 * File: program.cpp
 * -----------------
 * This file is a stub implementation of the program.h interface
 * in which none of the methods do anything beyond returning a
 * value of the correct type.  Your job is to fill in the bodies
 * of each of these methods with an implementation that satisfies
 * the performance guarantees specified in the assignment.
 */

#include <string>
#include <map> 
#include <iostream>
#include "program.h"
#include "statement.h"
using namespace std;
//Li Jia Sen 's  Min Program of Basic

//map<int, string> myline;
void Program::ListMap(){
	map<int ,string > :: iterator it1;
	it1=myline.begin();
	while (it1!=myline.end()){
		cout<<(*it1).second<<endl;
		++it1;
	}
}
bool Program:: CheckNumber(int linenum){
	map<int ,string > :: iterator it1;
	it1=myline.find(linenum);
	if (it1==myline.end()) return false;
	return true;
}
Program::Program() {
	// Replace this stub with your own code
	myline.clear();
}

Program::~Program() {
	// Replace this stub with your own code
	myline.clear();
	
}

void Program::clear() {
	// Replace this stub with your own code
	myline.clear();
}

void Program::addSourceLine(int lineNumber, string line) {
	// Replace this stub with your own code
	myline[lineNumber]=line;
}

void Program::removeSourceLine(int lineNumber) {
	// Replace this stub with your own code
	map<int, string>::iterator it1;
	it1=myline.find(lineNumber);
	myline.erase(it1);
}

string Program::getSourceLine(int lineNumber) {
	// Replace this stub with your own code
   map<int, string>::iterator it1;
   it1=myline.find(lineNumber);
   if (it1==myline.end()) throw (string("LINE NUMBER ERROR"));
   return (*it1).second;
}

void Program::setParsedStatement(int lineNumber, Statement *stmt) {
	// Replace this stub with your own code
}

Statement *Program::getParsedStatement(int lineNumber) {
	return NULL;  // Replace this stub with your own code
}

int Program::getFirstLineNumber() {
	map<int, string>::iterator it1;
	it1=myline.begin();
	return (*it1).first;     // Replace this stub with your own code
}

int Program::getNextLineNumber(int lineNumber) {
	map<int, string>::iterator it1;
	it1=myline.find(lineNumber);
	++it1;
	if (it1==myline.end()){
		return -1;
	}
	return (*it1).first;     // Replace this stub with your own code
}
