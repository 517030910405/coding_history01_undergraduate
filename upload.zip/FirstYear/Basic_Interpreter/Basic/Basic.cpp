/*
 * File: Basic.cpp
 * ---------------
 * Name: [TODO: enter name here]
 * Section: [TODO: enter section leader here]
 * This file is the starter project for the BASIC interpreter from
 * Assignment #6.
 * [TODO: extend and correct the documentation]
 */

#include <cctype>
#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>
#include "exp.h"
#include "parser.h"
#include "program.h"
#include "../StanfordCPPLib/error.h"
#include "../StanfordCPPLib/tokenscanner.h"
#include "../StanfordCPPLib/tokenscanner.cpp"
#include "evalstate.cpp"
#include "program.cpp"

#include "../StanfordCPPLib/simpio.h"
#include "../StanfordCPPLib/simpio.cpp"
#include "../StanfordCPPLib/strlib.h"
using namespace std;

/* Function prototypes */
//Usage (You Know)
void processLine(string line, Program & program, EvalState & state);


//Run exactly one line 
//the try- version is used to determin whether it could to run 
void operate(string line, Program & program, EvalState & state);
void tryoperate(string line, Program & program, EvalState & state);


//Used to run the "RUN"
void runnerlee(Program & program, EvalState & state);

/* Main program */
stringstream transtr;
int main() {
	EvalState state;
	Program program;
	//cout << "Stub implementation of BASIC" << endl;
	while (true) {
		try {
			processLine(getLine(), program, state);
		} catch (ErrorException & ex) {
			//cout << "Error: " << ex.getMessage() << endl;
			string st1=ex.getMessage();
			if (st1.substr(st1.length()-10,10)=="expression"){
				cout<<"SYNTAX ERROR"<<endl;
			}
			if (st1.substr(st1.length()-9,9)=="undefined"){
				cout<<"VARIABLE NOT DEFINED"<<endl;
			}
		} catch (string st){
			cout << st<<endl;	
		}
	}
	return 0;
}

/*
 * Function: processLine
 * Usage: processLine(line, program, state);
 * -----------------------------------------
 * Processes a single line entered by the user.  In this version,
 * the implementation does exactly what the interpreter program
 * does in Chapter 19: read a line, parse it as an expression,
 * and then print the result.  In your implementation, you will
 * need to replace this method with one that can respond correctly
 * when the user enters a program line (which begins with a number)
 * or one of the BASIC commands, such as LIST or RUN.
 */
void runnerlee(Program & program, EvalState & state){
	int pos=program.getFirstLineNumber();
	while (true){
		if (pos==-1) return;
		string line=program.getSourceLine(pos);
		
		//cout<<line<<endl;
		pos=program.getNextLineNumber(pos);
		TokenScanner scanner;
		scanner.ignoreWhitespace();
		//scanner.scanNumbers();
		scanner.setInput(line);
		scanner.nextToken();//过滤行号
		string st1=scanner.nextToken();
		if (st1 == "GOTO"){
			int newlinenum;
			{
				string st2 = scanner.nextToken();
				newlinenum = stringToInteger(st2);
			}
			pos = newlinenum;
		} else
		if (st1 == "IF"){
			int newlinenum;
			{
				string st2 = "", st3 = "", st4 = "", st5 ;
				st3 = scanner.nextToken();
				while (st3 != "=" && st3 != "<" && st3 != ">"){
					st2 = st2 + st3 ;
					st3 = scanner.nextToken();
				}
				st5 = scanner.nextToken();
				while (st5 != "THEN"){
					st4 = st4 + st5;
					st5 = scanner.nextToken();
				}
				TokenScanner scanner1;
				scanner1.ignoreWhitespace();
				//scanner.scanNumbers();
				scanner1.setInput(st2);
				Expression *exp1 = parseExp(scanner1);
				int value1 = exp1 ->eval(state);
				//cout << value1 << endl;
				
				TokenScanner scanner2;
				scanner2.ignoreWhitespace();
				//scanner.scanNumbers();
				scanner2.setInput(st4);
				Expression *exp2 = parseExp(scanner2);
				int value2 = exp2 ->eval(state);
				//cout << value2 << endl;
				
				if ((st3 == "=" && value1 == value2 ) || (st3 == "<" && value1 < value2) || (st3 == ">" && value1 > value2 )){
					st5 = scanner.nextToken();
					newlinenum = stringToInteger(st5);
					pos = newlinenum;
				}
			}
			
			
		} else
		if (st1 == "END"){
			{
				return;
			}
		} else{
			{
				int startPoint = 0;
				while (line [ startPoint ] <= '9' && line [ startPoint ] >= '0' ){
					++startPoint;
				}
				//cout<<line.substr(startPoint+1,line.length()-startPoint-1)<<endl;
				operate(line.substr(startPoint + 1, line.length() - startPoint - 1 ), program, state);
				
			}
		}
	}
	
	
}
 
 

void operate(string line, Program & program, EvalState & state){
	//cout<<line<<endl;
	TokenScanner scanner;
	scanner.ignoreWhitespace();
	//scanner.scanNumbers();
	scanner.setInput(line);
	string st1=scanner.nextToken();
	
	if (st1=="REM"){
		//check
		//empty 
		return;
	}
	if (st1=="LET"){
		{
			//You can add "try" wherever you want
			string st2 = scanner.nextToken();
			string st3 = scanner.nextToken();
			if (st2 == "LET" || st2 == "REM" || st2 == "PRINT" || st2 == "INPUT" || st2 == "END" || st2 == "IF" || st2 == "THEN"
			|| st2 == "GOTO" ||
			st2 == "RUN" || st2 == "LIST" || st2 == "CLEAR" || st2 == "QUIT" || st2 == "HELP" ){
				throw (string("SYNTAX ERROR"));
				
			}
			Expression *exp = parseExp(scanner);
			int value = exp->eval(state);
			//cout << value << endl;
			state.setValue(st2,value);
		} 
		return; 
	}
	if (st1=="PRINT"){
		{
			Expression *exp = parseExp(scanner);
			int value = exp->eval(state);
			cout << value << endl;
		}
		return;
	}
	
	if (st1=="INPUT"){
		int inp;
		string st2 = scanner.nextToken();
		if (scanner.hasMoreTokens()){
			throw (string("SYNTAX ERROR"));
			return;
		}
		while (true){
			string line1;
			cout<<" ? ";
			line1 = getLine();
			try{
				inp = stringToInteger(line1);
				state.setValue(st2,inp);
				return;
			} catch(...){
				cout<<(string("INVALID NUMBER"))<<endl;
			}		
		}
	}
}
void tryoperate(string line, Program & program, EvalState & state){
	//cout<<line<<endl;
	TokenScanner scanner;
	scanner.ignoreWhitespace();
	//scanner.scanNumbers();
	scanner.setInput(line);
	string st1 = scanner.nextToken();
	
	if (st1 == "REM"){
		//check
		//empty 
		return;
	}
	if (st1 == "LET"){
		{
			string st2 = scanner.nextToken();
			string st3 = scanner.nextToken();
			if (st2=="LET"||st2=="REM"||st2=="PRINT"||st2=="INPUT"||st2=="END"||st2=="IF"||st2=="THEN"||st2=="GOTO"||
			st2=="RUN"||st2=="LIST"||st2=="CLEAR"||st2=="QUIT"||st2=="HELP"){
				throw (string("SYNTAX ERROR"));
			}
			Expression *exp = parseExp(scanner);
			try{
				int value = exp->eval(state);
			} catch(ErrorException &ex){
				string st1 = (ex.getMessage());
				//cout<<st1<<endl;
				if (st1.substr(st1.length() -9, 9) != "undefined"){
					throw (string("SYNTAX ERROR"));
				}
			}
			//cout << value << endl;
			//state.setValue(st2,value);
		} 
		return; 
	}
	if (st1=="PRINT"){
		try{
			Expression *exp = parseExp(scanner);
			int value = exp->eval(state);
			//cout << value << endl;
		}catch(ErrorException &ex ){
			string st1=(ex.getMessage());
			//cout<<st1<<endl;
			if (st1.substr(st1.length() -9, 9) != "undefined"){
				throw (string("SYNTAX ERROR"));
			}
		}
		return;
	}
	
	if (st1=="INPUT"){
		int inp;
		string line1;
		//cout<<" ? ";
		//line1=getLine();
		string st2 = scanner.nextToken();
		if (scanner.hasMoreTokens()){
			throw(string("SYNTAX ERROR"));
			return;
		}
		return;		
	}
}
 
 
 
void processLine(string line, Program & program, EvalState & state) {
	if (line=="") return ;
	TokenScanner scanner;
	scanner.ignoreWhitespace();
	//scanner.scanNumbers();
	scanner.setInput(line);
	string st1 = scanner.nextToken();
	int linenum = -1;
	//cout<<"("<<st1<<")"<<endl;
	if (st1[0] <= '9' && st1[0] >= '0'){
		{
			linenum = stringToInteger(st1);
			//cout<<linenum<<endl;
			if (!scanner.hasMoreTokens()){
				if (program.CheckNumber(linenum))program.removeSourceLine(linenum);
				return;
			}
			int startPoint=0;
			while (line[startPoint] <= '9' && line[startPoint] >= '0'){
				++startPoint;
			}
			//cout<<line.substr(startPoint+1,line.length()-startPoint-1)<<endl;
			tryoperate(line.substr(startPoint +1, line.length() -startPoint -1), program,state);
		} 
		//check the line
		program.addSourceLine(linenum, line);
		return;
	}
	
	if (st1=="LIST"){
		program.ListMap();
		return;
	}
	if (st1=="RUN"){
		runnerlee(program, state);
		return;
	}
	if (st1=="CLEAR"){
		program.clear();
		state.clear();
		return;
	}
	if (st1=="QUIT"){
		exit(0);
		return;
	}
	if (st1=="HELP"){
		
		return;
	}
	operate(line, program, state);
	return;
	Expression *exp = parseExp(scanner);
	int value = exp->eval(state);
	cout << value << endl;
	delete exp;
}




