This was a book store back end. 
 It has a very simple self-made data management system
 Detailed infomation is writen in the assignment Version 6
 (网上书店管理系统作业要求v6.pdf)
 
 