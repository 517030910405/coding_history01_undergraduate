import java.util.*;
public class varname {
    public String name = "";// myInt/f()/b1b2b3/ etc
    public String type = "";// class/function/int etc
    //public HashMap<String, varname> namer = new HashMap<String, varname>();
    //If type is class then there is sub namespace
    public int array_dim = 0;
    public node location=null;//Maybe no need ?
    public boolean activate = false;
    public int mem_position = 0;//for user_class
    //public int mem_position_size = 0;
    //if function
}
