#include<stdio.h>
int main(){
	char a[100];
	scanf("%[^ ]",a);
	printf("%s",a);
}