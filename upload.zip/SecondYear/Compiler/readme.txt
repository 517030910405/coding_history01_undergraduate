This compiler is developed by Li Jiasen
Compiler Language Mx* (pseudo Java)
Developing Language Java
from mx* to nasm