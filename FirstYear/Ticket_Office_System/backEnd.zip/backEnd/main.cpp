#include <iostream>
#include "utility.h"
#include "processor.h"

int main() {
    sjtu::processor prcs;
    prcs.master();
    return 0;
}