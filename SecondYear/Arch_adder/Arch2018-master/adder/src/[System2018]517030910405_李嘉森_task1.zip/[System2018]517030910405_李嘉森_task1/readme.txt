The file includes 5 adder 's

1."adder.v"
Naive Version of adder named Ripple-carry adder
(Using genvar)

2."adder2.v"
The faster Version named Carry-lookahead adder
The place is very big
(Using genvar)

3."adder3.v"
Naive Version of adder named Ripple-carry adder
(Using genvar)
(Recursive definition)


All the 5 adders are available for vivado. 


Reference:
Advanced Dightal Design with the Verilog HDL
 by Michael D. Ciletti

